package com.foodOnline.exception;

public class BusinessException extends Exception{

	public BusinessException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BusinessException(final String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
