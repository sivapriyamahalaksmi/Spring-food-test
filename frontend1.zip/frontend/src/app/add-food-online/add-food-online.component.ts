import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-food-online',
  templateUrl: './add-food-online.component.html',
  styleUrls: ['./add-food-online.component.css']
})
export class AddFoodOnlineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
