import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-food-online',
  templateUrl: './update-food-online.component.html',
  styleUrls: ['./update-food-online.component.css']
})
export class UpdateFoodOnlineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
