import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-food-online',
  templateUrl: './delete-food-online.component.html',
  styleUrls: ['./delete-food-online.component.css']
})
export class DeleteFoodOnlineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
